from django.apps import AppConfig


class CustomuserConfig(AppConfig):
    name = 'customuser'
