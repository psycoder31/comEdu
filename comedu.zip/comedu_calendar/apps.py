from django.apps import AppConfig


class ComeduCalendarConfig(AppConfig):
    name = 'comedu_calendar'
